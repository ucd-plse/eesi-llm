#!/bin/bash

source bazel_python_venv_installed/bin/activate
python $@
